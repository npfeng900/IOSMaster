//
//  Place.m
//  WhereAmI
//
//  Created by Kim Topley on 6/25/14.
//  Copyright (c) 2014 Apress. All rights reserved.
//

#import "Place.h"

@implementation Place

@end
