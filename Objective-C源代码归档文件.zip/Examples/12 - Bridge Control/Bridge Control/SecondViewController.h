//
//  SecondViewController.h
//  Bridge Control
//
//  Created by Kim Topley on 7/27/14.
//  Copyright (c) 2014 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController


@end

