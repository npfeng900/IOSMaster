//
//  FontSizesViewController.h
//  Fonts
//
//  Created by Kim Topley on 10/11/14.
//  Copyright (c) 2014 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FontSizesViewController : UITableViewController

@property (strong, nonatomic) UIFont *font;

@end
