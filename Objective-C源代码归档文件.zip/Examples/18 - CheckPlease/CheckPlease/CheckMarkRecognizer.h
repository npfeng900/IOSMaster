//
//  CheckMarkRecognizer.h
//  CheckPlease
//
//  Created by Kim Topley on 7/22/14.
//  Copyright (c) 2014 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckMarkRecognizer : UIGestureRecognizer

@end
