// Temporary file to work around Swift problem
#import <UIKit/UIGestureRecognizerSubclass.h>
